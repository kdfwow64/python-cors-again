$(document).ready(function() {
	var operator = 0;
    // Apply the plugin on a standard, empty div...
    var $flowchart = $('#start');
    $flowchart.flowchart({
      data: start
    });
    $flowchart.siblings('.get_data').click(function() {
      var data = $flowchart.flowchart('getData');
      $('#flowchart_data').val(JSON.stringify(data, null, 2));
    });


    $flowchart.siblings('.configurationParser').click(function() {
      var operatorId = 'job-' + operator;
      var operatorData = {
        top: 60,
        left: 700,
        properties: {
          title: '<a href=""  class="text-center" id="' + operatorId + '">Parser</a>' ,
          inputs: {
            input_1: {
              label: ' ',}
          },
          outputs: {
            success: {
              label: 'success',},
            failure: {
              label: 'failure',
            }

          }
        }
      };


      $('#start').flowchart('createOperator', operatorId, operatorData);
      operator++;
    });
    
    $flowchart.siblings('.configurationSender').click(function() {
        var operatorId = 'job-' + operator;
        var operatorData = {
          top: 60,
          left: 100,
          properties: {
            title: '<a href=""  class="text-center" id="' + operatorId + '">Sender</a>' ,
            inputs: {
              input_1: {
                label: ' ',}
            },
            outputs: {
              success: {
                label: ' success ',},
              failure: {
                label: 'failure',
              }

            }
          }
        };


        $('#start').flowchart('createOperator', operatorId, operatorData);        
        operator++;
      });
    $flowchart.siblings('.differPrecheck').click(function() {
        var operatorId = 'job-' + operator;
        var operatorData = {
          top: 60,
          left: 500,
          properties: {
            title: '<a href=""  class="text-center" id="' + operatorId + '">Precheck</a>' ,
            inputs: {
              input_1: {
                label: ' ',}
            },
            outputs: {
              success: {
                label: 'success',},
              failure: {
                label: 'failure',
              }

            }
          }
        };


        $('#start').flowchart('createOperator', operatorId, operatorData); 
        operator++;
      });
    $flowchart.siblings('.differPostcheck').click(function() {
        
        var operatorId = 'job-' + operator;
        var operatorData = {
          top: 60,
          left: 300,
          properties: {
            title: '<a href=""  class="text-center" id="' + operatorId + '">Postcheck</a>' ,
            inputs: {
              input_1: {
                label: ' ',}
            },
            outputs: {
              success: {
                label: ' success ',},
              failure: {
                label: 'failure',
              }

            }
          }

        };


        $('#start').flowchart('createOperator', operatorId, operatorData);
        operator++;
      });
    $flowchart.siblings('.imageLoader').click(function() {
        var operatorId = 'job-' + operator;
        var operatorData = {
          top: 60,
          left: 900,
          properties: {
            title: '<a href=""  class="text-center" id="' + operatorId + '">Image Loader</a>' ,
            inputs: {
              input_1: {
                label: ' ',}
            },
            outputs: {
              success: {
                label: ' success ',},
              failure: {
                label: 'failure',
              }

            }
          }
        };


        $('#start').flowchart('createOperator', operatorId, operatorData);
        operator++;
      }); 
    $flowchart.siblings('.starting').click(function() {
        var operatorId = 'start';
        var operatorData = {
          top: 200,
          left: 0,
          properties: {
            title: '<div  class="text-center" id="' + operatorId + '">start</div>' ,
            outputs: {
              success: {
                label: ' success ',}
             

            }
          }
        };


        $('#start').flowchart('createOperator', operatorId, operatorData);
      });
    $flowchart.siblings('.success').click(function() {
        var operatorId = 'success';
        var operatorData = {
          top: 160,
          left: 1000,
          properties: {
            title: '<div  class="text-center" id="' + operatorId + '">success</div>' ,
            inputs: {
                input_1: {
                  label: ' ',}
              },
          }
        };


        $('#start').flowchart('createOperator', operatorId, operatorData);
      });
    $flowchart.siblings('.fail').click(function() {
        var operatorId = 'failure';
        var operatorData = {
          top: 260,
          left: 1000,
          properties: {
            title: '<div  class="text-center" id="' + operatorId + '">fail</div>' ,
            inputs: {
                  input_1: {
                  label: ' ',}
              },
          }
        };


        $('#start').flowchart('createOperator', operatorId, operatorData);
      });
    
    $flowchart.siblings('.Evaluation').click(function() {
        var operatorId = 'eval-' + operator;
        var operatorData = {
          top: 200,
          left: 900,
          properties: {
            title: '<a href=""  class="text-center" id="' + operatorId + '">Evaluation</a>' ,
            inputs: {
                input_1: {
                label: ' ',}
            },
            outputs: {
              success: {
                label: ' success ',},
              failure: {
                label: 'failure',
              }

            }
          }
        };


        $('#start').flowchart('createOperator', operatorId, operatorData); 
        operator++;
      });


    $flowchart.siblings('.delete_selected_button').click(function() {
      $flowchart.flowchart('deleteSelected');
    });
    
    $flowchart.siblings('.get_data').click(function() {
      var data = $flowchart.flowchart('getData');
      $('#flowchart_data').val(JSON.stringify(data, null, 2));
    });

  });
