	var ruleId = 1;

	jQuery(function(){
		
		$('#trigger_table').DataTable({
		
		 "columnDefs": [
		        {
		         "targets": [ 2 ] ,
		         "searchable": false
		        }, 
		    ]
		})
		
		
		
		//================================add rule==============================
		  
		$('#element1').change(function(){
			
			$('.column option').show();
			var table = document.getElementById("ruleTable");
			for(id=2;id<=table.rows.length;id++){
			$("#element"+id).hide();
			}
			 if ($(this).data('options') === undefined) {
     		    
     		    $(this).data('options', $('.column option').clone());
     		    
     		    //$(this).data('options', $('.element option').clone())
     		  }
			 var id=$(this).val()
			 var options = $(this).data('options').filter('[class=' + id + ']');
			 $('.column').html(options); 
			  
		});
		 
		
    jQuery('a.add-rule').click(function(event){
    	
        event.preventDefault();
        ruleId++;
        var newRow = jQuery(`
		                    <tr id="rul` + ruleId + `">
		                    <input type="hidden" id="rule` + ruleId + `" name="rules">
		                    
		                    <td class="right-color td-border">
		                    	 <select id="element` + ruleId + `" class="form-control" >
	                    				<option selected>--choose from here--</option>
	                    				<option value="task">device</option>
	                    				<option value="job">job</option>       
				                    </select>
		                    </td>
		                    
		                    <td class="right-color td-border">
                                 <Select class="form-control column" id="column` + ruleId + `">
                                 	<option selected>--choose from here--</option>
                                 </Select>
                            </td>
		                  	
		                    <td class="right-color td-border">
								<Select id="operation` + ruleId + `" class="form-control">
									<option selected>--choose from here--</option>                               
		                            <option value="equals">equals</option>
		                            <option value="not equals">not equals</option>
		                       	</Select> 	
		                   	</td>
		                       	
		                    <td class="right-color td-border">
		                    <input id="value` + ruleId + `" type="text" class="form-control" >		                  
		                   	</td>  
                    </tr>`);
       
       
        jQuery('table.rule-list').append(newRow);
        
        $('#element1').change();
       
    });

		
    $('#formRule').submit(function(event) {
    	
		var table = document.getElementById("ruleTable");
		var rule=new Array();
		
		for(ruleId=1;ruleId<=table.rows.length;ruleId++){
			if (ruleId == 1){
				element_val = $('#element'+ruleId).val()
			}else{
				element_val = $('#element1').val()
			}
			rule.push({					  
				       
					  	element: element_val,
				    	column:$('#column'+ruleId).val(),
				    	operation: $('#operation'+ruleId).val(),
				    	value: $('#value'+ruleId).val()
				 
		    		});
			
			data=JSON.stringify(rule);		
		    var rules=document.getElementById("rule"+ruleId);		    
		    rules.value=data;
		}  
    })
    
                  //=============================edit rule===================================
     
    
    
    jQuery('a.edit_rule').click(function(event){
    	
    	var ids=this.id
    	var td_table = document.getElementById("edit_ruleTable_"+ids);
    	
    	for(var i=2;i<=td_table.rows.length;i++){
    	
    	 td_rule=document.getElementById("td_"+ids+"_"+i)
    	 td_rule.style.visibility="hidden"
    		
    	}
    });
    
   
    jQuery('a.edit_add_rule').click(function(event){
    	event.preventDefault();
    	   
    	var index=this.id
    	var edit_table = document.getElementById("edit_ruleTable_"+index);
    	var edit_rule_id = edit_table.rows.length
        var newRow = jQuery(`
		                    <tr id="edit_rul_`+ index +`_` + edit_rule_id + `">
		                    <input type="hidden" id="edit_rules_`+ index +`_`+ edit_rule_id + `" name="rules">
		                    
		                    <td class="right-color td-border">		                   
				                    <select id="edit_element_`+ index +`_`+ edit_rule_id + `" class="form-control edit_element" style="width:135px;" >              	                	                    			
	                    				<option value="task">device</option>
                    					<option value="job">job</option>  
				                    </select>
		                    </td>
		                    
		                    <td class="right-color td-border">
                                 <Select class="form-control edit_column_`+ index +`" id="edit_column_`+ index +`_` + edit_rule_id + `">
                                 	<option selected>--choose from here--</option>
                                 </Select>
                            </td>
		                  	
		                    <td class="right-color td-border">
								<Select id="edit_operation_`+ index +`_` + edit_rule_id + `" class="form-control">
									<option selected>--choose from here--</option>                               
		                            <option value="equals">equals</option>
		                            <option value="not equals">not equals</option>
		                       	</Select>
		                   	</td>
		                       	
		                    <td class="right-color td-border">
		                    <input id="edit_value_`+ index +`_` + edit_rule_id + `" type="text" class="form-control" >		                  
		                   	</td>  
                    </tr>`);
       
        jQuery('table#edit_ruleTable_'+index).append(newRow);
        $('.edit_element').change();
       
    });
 
 });         
		  
	 function showId(obj) {
		 
		 var table = document.getElementById("edit_ruleTable_"+obj);
		
			for(index=2;index<=table.rows.length;index++){
			$("#edit_element_"+obj+"_"+index).hide();
			}
			
		 	$('#edit_element_'+obj+'_1').change(function(){
			 
			 for(ruleId=1;ruleId<=table.rows.length;ruleId++){

				 $('.edit_column_'+obj+' option').show();
			 
			    if ($(this).data('options') === undefined) {
			    	 $(this).data('options', $('#edit_column_'+obj+'_'+ruleId+' option').clone());
			    }
			   
			 var id=$(this).val()
			 var options = $(this).data('options').filter('[class=' + id + ']');
			 $('.edit_column_'+obj).html(options);
			 
			 }	 
	});
		 
	        $('.edit_formRule').submit(function(event) {
	        	
	    		var table = document.getElementById("edit_ruleTable_"+obj);
	    		var rule=new Array();
	    		
	    		for(ruleId=1;ruleId<=table.rows.length;ruleId++){
	    			if (ruleId == 1){
	    				edit_element_val = $('#edit_element_'+obj+'_'+ruleId).val()
	    			}else{
	    				edit_element_val = $('#edit_element_'+obj+'_1').val()
	    			}
	    			 rule.push({
	    					
	    					element: edit_element_val,
	    			    	column:$('#edit_column_'+obj+'_'+ruleId).val(),
	    			    	operation: $('#edit_operation_'+obj+'_'+ruleId).val(),
	    			    	value: $('#edit_value_'+obj+'_'+ruleId).val()
	    			})
	    			
	    			data=JSON.stringify(rule);
	    			var rules=document.getElementById("edit_rules_"+obj+"_"+ruleId);
	    		    rules.value=data;
	    	}
	     });  
	  }
	