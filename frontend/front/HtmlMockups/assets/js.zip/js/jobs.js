$(document).ready(function() {
    $('#dataTableId').DataTable( {
        "pagingType": "full_numbers",
        "order":[4, 'desc'],
        "columnDefs": [
            {
                "targets": [ 8 ],
                "searchable": false
            }, 
        ]
    } );
} );

$(document).ready(function() {
    $('#precheckTableId').DataTable( {
        "pagingType": "full_numbers",
        "order":[4, 'desc'],
        
    } );
} );


$(document).ready(function() {
    $('#taskreporttable').DataTable( {
        "pagingType": "full_numbers",
        "order":[3, 'desc'],
        "columnDefs": [
            {
                "targets": [ 6 ],
                "searchable": false
            }, 
        ]
    } );
	function showHideBoolean() {
    	this.addEventListener("click", function(){
        	var test = this.value;
            if (test == 'hidden') {
              $("#" + this.id + '-div').show();
              }
	})}
    $("button[name='hiddentd']").each(showHideBoolean);

    
} );

$(document).ready(function() {
    $('#jobreporttable').DataTable( {
        "pagingType": "full_numbers",
        "order":[3, 'desc'],
        "columnDefs": [
            {
                "targets": [ 9 ],
                "searchable": false
            }, 
        ]
    } );
} );
$(function() {
    $('#btnAdd1').click(function() {
        $('.td1').toggle();
    });
});

$(document).ready(function() {
	
	
	function showHideBooleanEdit() {
		
		/*var chihaja = 0;
		for (chihaja=0; chihaja<1000; chihaja++){
	    document.getElementById("edit_configuration_sender_credentials").id = "edit_configuration_sender_credentials"+chihaja+"-div";*/
		
		
		
		if (this.id.indexOf('-div') !== -1) {
			return;
		}
    	this.addEventListener("click", function(){
        	var test = this.value;
        	if (test == 'true') {
            $("#" + "use_device_credentials"+"-div").hide();
            
            }
       
          else {
        	  $("#" + "use_device_credentials"+"-div").show();

          }
	})
    	/*}*/
	}
	
	function showHideBooleanHostTypeMultipleEdit() {
		if (this.id.indexOf('-div') !== -1) {
			return;
		}
		
		
    	this.addEventListener("click", function(){
        	var test = this.value;
        	
        	if (test == 'load_host_command_file') {
            $("#" + "edit_achoice1-div").show();
            $("#" + 'edit_achoice2-div').hide();
            $("#" + 'edit_achoice3-div').hide();
            
            }
          else if (test == 'choose_host_write_command'){
        	  $("#" + 'edit_achoice1-div').hide();
        	  $("#" + 'edit_achoice2-div').show();
        	  $("#" + 'edit_achoice3-div').hide();
          }
          else {
        	  $("#" + 'edit_achoice1-div').hide();
        	  $("#" + 'edit_achoice2-div').hide();
        	  $("#" + 'edit_achoice3-div').show();
          }
        	
	})}

	function showEditSender() {
    	this.addEventListener("click", function(){
    		
    		/*$(function() {
    		    $('#editConfigurationSender').change(function(){
    		        $('.editConfigurationSender').hide();
    		        $('#' + $(this).val()).show();
    		    });
    		});
    		*/
    	
        	var test = this.value;
            if (test == 'configuration_sender') {
              $("#" + "editConfigurationSender").show();
              //$("#" + 'editConfigurationSender').show();            
              //$("#" + 'editImageLoader').hide();
              //$("#" + 'editDifferPostcheck').hide();
              //$("#" + 'editDifferPretcheck').hide();
              }
            /*else if (test == 'configuration_sender') {
            	$("#" + 'editConfigurationSender').show();
                $("#" + 'editConfigurationParser').hide();
                $("#" + 'editImageLoader').hide();
                $("#" + 'editDifferPostcheck').hide();
                $("#" + 'editDifferPretcheck').hide();
            }
            else if (test == 'image_loader') {
            	$("#" + 'editConfigurationSender').show();
                $("#" + 'editConfigurationParser').hide();
                $("#" + 'editImageLoader').hide();
                $("#" + 'editDifferPostcheck').hide();
                $("#" + 'editDifferPretcheck').hide();
            }*/
          
    	})};
    	
	    $("input[name='editUseDeviceCredentials']").each(showHideBooleanEdit);

    	//$("input[name='agent_type']").each(showEditSender);
    	$("input[id^='edit_achoice']").each(showHideBooleanHostTypeMultipleEdit);
	});

