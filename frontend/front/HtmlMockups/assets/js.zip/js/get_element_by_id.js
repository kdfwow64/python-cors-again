 <script type="text/javascript">
        function showDiv(elem){
    if(elem.value == 1)
        document.getElementById('hidden_1').style.display = "block";
    else
        document.getElementById("hidden_1").style.display="none";
    if (elem.value == 2)
        document.getElementById('hidden_2').style.display = "block"; 
    else
        document.getElementById("hidden_2").style.display="none";
    if (elem.value == 3)
        document.getElementById('hidden_3').style.display = "block"; 
    else
        document.getElementById("hidden_3").style.display="none";
    if (elem.value == 4)
        document.getElementById('hidden_4').style.display = "block"; 
    else
        document.getElementById("hidden_4").style.display="none";
    if (elem.value == 5)
        document.getElementById('hidden_5').style.display = "block"; 
    else
        document.getElementById("hidden_5").style.display="none";
    if (elem.value == 6)
        document.getElementById('hidden_6').style.display = "block"; 
    else
        document.getElementById("hidden_6").style.display="none";
    if (elem.value == 7)
        document.getElementById('hidden_7').style.display = "block"; 
    else
        document.getElementById("hidden_7").style.display="none";
    if (elem.value == 100)
        document.getElementById('hidden_100').style.display = "block"; 
    else
        document.getElementById("hidden_100").style.display="none";
    if (elem.value == 110)
        document.getElementById('hidden_110').style.display = "block"; 
    else
        document.getElementById("hidden_110").style.display="none";
    if (elem.value == 120)
        document.getElementById('hidden_120').style.display = "block"; 
    else
        document.getElementById("hidden_120").style.display="none";
    if (elem.value == 130)
        document.getElementById('hidden_130').style.display = "block"; 
    else
        document.getElementById("hidden_130").style.display="none";
    if (elem.value == 140)
        document.getElementById('hidden_140').style.display = "block"; 
    else
        document.getElementById("hidden_140").style.display="none";
    if (elem.value == 150)
        document.getElementById('hidden_150').style.display = "block"; 
    else
        document.getElementById("hidden_150").style.display="none";
    if (elem.value == 160)
        document.getElementById('hidden_160').style.display = "block"; 
    else
        document.getElementById("hidden_160").style.display="none";
    if (elem.value == 170)
        document.getElementById('hidden_170').style.display = "block"; 
    else
        document.getElementById("hidden_170").style.display="none"; 
}
    </script>